import { useState } from "react";
import ringStore from "../../data/RingStore";
import "./RingReleasePanel.css";

const today = new Date().toISOString().slice(0, 10);

export default function RingReleasePanel({ entry, onChange }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [releaseDate, setReleaseDate] = useState(today);
  const [notes, setNotes] = useState("");

  function releaseRing(event) {
    event.preventDefault();
    const historyRecord = ringStore.releaseFromBreedingEntry(
      entry.id,
      entry.ringNumber,
      { reason, releaseDate, notes: notes.trim() },
    );

    onChange?.(entry.id, {
      ringNumber: "",
      ringHistory: [...(entry.ringHistory || []), historyRecord],
    });
    setOpen(false);
  }

  if (!open) {
    return (
      <button
        className="ring-release-open"
        type="button"
        onClick={() => setOpen(true)}
      >
        Release / Reassign Ring
      </button>
    );
  }

  return (
    <form className="ring-release-panel" onSubmit={releaseRing}>
      <strong>Release {entry.ringNumber}</strong>

      <label>
        Reason
        <select value={reason} onChange={(event) => setReason(event.target.value)} required>
          <option value="">Select reason</option>
          <option>Youngster died</option>
          <option>Ring removed</option>
          <option>Incorrectly assigned</option>
          <option>Other</option>
        </select>
      </label>

      <label>
        Date Released
        <input type="date" value={releaseDate} onChange={(event) => setReleaseDate(event.target.value)} required />
      </label>

      <label className="ring-release-notes">
        Notes
        <input value={notes} onChange={(event) => setNotes(event.target.value)} />
      </label>

      <div className="ring-release-actions">
        <button className="secondary" type="button" onClick={() => setOpen(false)}>Cancel</button>
        <button className="primary" type="submit">Confirm Release</button>
      </div>
    </form>
  );
}
